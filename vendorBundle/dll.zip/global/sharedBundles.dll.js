define(["sharedBundles"], function(sharedBundles) {
  return {};
});
